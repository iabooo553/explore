EdXposedManager
===============

Companion Android application for EdXposed.
