package org.meowcat.edxposed.manager.repo;

public class Repository {
    public String name;
    public String url;
    public boolean isPartial = false;
    public String partialUrl;
    public String version;

    Repository() {
    }
}
