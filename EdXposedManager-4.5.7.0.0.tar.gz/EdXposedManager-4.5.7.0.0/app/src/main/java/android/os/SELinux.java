package android.os;

/*
 * Stub!
 * Decompiled by MlgmXyysd.
 */
public class SELinux {
    public static native boolean isSELinuxEnabled();
}