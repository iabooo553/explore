package android.os;

/*
 * Stub!
 * Decompiled by MlgmXyysd.
 */
public class SystemProperties {
    @SuppressWarnings("unused")
    public static String get(String key, String def) {
        throw new RuntimeException("Stub!");
    }
}