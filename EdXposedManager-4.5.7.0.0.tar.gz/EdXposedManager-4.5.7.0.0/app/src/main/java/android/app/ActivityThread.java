package android.app;

/*
 * Stub!
 * Decompiled by MlgmXyysd.
 */
public class ActivityThread {
    @SuppressWarnings("unused")
    boolean mHiddenApiWarningShown = false;

    public static ActivityThread currentActivityThread() {
        throw new RuntimeException("Stub!");
    }
}
