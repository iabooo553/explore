###### Include the following:
 - EdXposed Version: `0.4.6.2`
 - Android Version: `10`
 - Device Manufacturer: `OnePlus`
 - Device Name: `7T Pro`
 - EdXposed Manager Version: `4.5.6`
 
###### Reproduction Steps

1. 
2. 
3. 

###### Expected Result


###### Actual Result
